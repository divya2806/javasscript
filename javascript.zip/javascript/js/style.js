var array = [];
var localObj = {};
localObj = JSON.parse(localStorage.getItem("user"));
	function myClick(){
		
		var nam = document.getElementById('name').value;
		var rol = document.getElementById('roll_no').value;
		var mal = document.getElementById('male').checked;
		var fem = document.getElementById('female').checked;
		var gender = "";

		
		if(mal){
			gender = "male";
		}
		else{
			gender = "female";
		}

		
		var form1 ={
					name: nam,
					roll_no: rol,
					gender: gender
				};

		array.push(form1);

		window.localStorage.setItem('user', JSON.stringify(array));

		document.getElementById('display').innerHTML +=  form1.name +   "<button onclick='getView(\""+ form1.name+"\")'> View </button>";
}

	

	function getView(name){
		document.getElementsByClassName('popup')[0].style.display = "block";
		array.forEach(function(obj){
			if(obj.name==name){
				document.getElementById("fullname").value= obj.name;
				document.getElementById("roll").value= obj.roll_no;

				document.getElementById("gender_new").value= obj.gender;
			}
		});
		
		
		

	}

	function getRegister(){
	document.getElementsByClassName('reg')[0].style.display = "block";

	}

	function getLogin(){
	document.getElementsByClassName('f1')[0].style.display = "block";
	document.getElementsByClassName('popup-login')[0].style.display = "none";
	}

	var closebtns = document.getElementsByClassName("close");
	var i;

	for (i = 0; i < closebtns.length; i++) {
  	closebtns[i].addEventListener("click", function() {
    this.parentElement.style.display = 'none';
  });



}